//
//  InterfaceController.swift
//  WatchApp WatchKit Extension
//
//  Created by iblesoft on 01/09/22.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    @IBOutlet var button : WKInterfaceButton?
    @IBOutlet var loader : WKInterfaceImage?

    override func awake(withContext context: Any?) {
        // Configure interface objects here.
        self.setTitle("Hello Jessy")
    }
    
    override func willActivate() {
        super.willActivate()
        self.showLoader()
        
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    func showLoader(){
        self.loader?.setHidden(false)
        self.button?.setHidden(true)
        loader?.setImageNamed("loader")
        self.loader?.startAnimatingWithImages(in: NSRange(location: 1, length: 8), duration: 0.8, repeatCount: -1)
    }
    
    func hideLoader(){
        self.loader?.setHidden(true)
        self.button?.setHidden(false)
        self.loader?.stopAnimating()
    }
    
    func setLoader(hidden:Bool){
        self.loader?.setHidden(hidden)
        self.button?.setHidden(!hidden)
    }
    
    @IBAction func tapStart() {
        self.showLoader()
    }
    
    @IBAction func tapStop(_ sender: Any) {
        self.hideLoader()
    }
    
}
